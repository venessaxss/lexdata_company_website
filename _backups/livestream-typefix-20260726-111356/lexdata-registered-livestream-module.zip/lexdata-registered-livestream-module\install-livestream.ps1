$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$moduleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = Join-Path $moduleRoot "payload"

foreach ($required in @(
  (Join-Path $root "package.json"),
  (Join-Path $root "lib\auth.ts"),
  (Join-Path $root "lib\supabase\admin.ts"),
  $payload
)) {
  if (-not (Test-Path -LiteralPath $required)) {
    throw "Cannot find required path: $required"
  }
}

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = Join-Path $root "_backups\livestream-$timestamp"
New-Item -ItemType Directory -Path $backup -Force | Out-Null

function Backup-File([string]$relativePath) {
  $source = Join-Path $root $relativePath
  if (-not (Test-Path -LiteralPath $source)) { return }

  $destination = Join-Path $backup $relativePath
  New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
  Copy-Item -LiteralPath $source -Destination $destination -Force
}

foreach ($relative in @(
  "app\workshops\[slug]\page.tsx",
  "lib\access-control.ts"
)) {
  Backup-File $relative
}

Write-Host "Backup: $backup" -ForegroundColor Cyan

# Copy module files into the project without touching .env.local.
Get-ChildItem -LiteralPath $payload -Recurse -File | ForEach-Object {
  $relative = $_.FullName.Substring($payload.Length).TrimStart("\")
  $destination = Join-Path $root $relative
  New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
  Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
}

# Add the shared access helper only when the project does not already have it.
$accessPath = Join-Path $root "lib\access-control.ts"

if (-not (Test-Path -LiteralPath $accessPath)) {
  $access = @'
export function canAccessWorkshop(registration: any) {
  if (!registration) return false;

  const status = String(registration.access_status || "").toLowerCase();

  if (["revoked", "blocked", "denied", "suspended"].includes(status)) {
    return false;
  }

  if (status === "granted") return true;

  return (
    registration.registration_status === "confirmed" ||
    registration.payment_status === "confirmed" ||
    registration.payment_status === "paid" ||
    registration.payment_status === "waived"
  );
}
'@

  [System.IO.File]::WriteAllText(
    $accessPath,
    $access,
    (New-Object System.Text.UTF8Encoding($false))
  )
}

# Add an Open live room button to the public workshop page when possible.
$workshopPagePath = Join-Path $root "app\workshops\[slug]\page.tsx"

if (Test-Path -LiteralPath $workshopPagePath) {
  $content = [System.IO.File]::ReadAllText($workshopPagePath)

  if ($content -notmatch 'Open live room') {
    if ($content -notmatch 'from "next/link"') {
      $content = 'import Link from "next/link";' + "`r`n" + $content
    }

    $pattern = '(?s)(<h1\b[^>]*>\s*\{workshop\.title\}\s*</h1>)'

    if ([regex]::IsMatch($content, $pattern)) {
      $link = @'

                <div className="mt-5">
                  <Link
                    href={`/workshops/${workshop.slug}/live`}
                    className="inline-flex rounded-2xl bg-slate-950 px-5 py-3 text-sm font-black text-white hover:bg-slate-700"
                  >
                    Open live room
                  </Link>
                </div>
'@

      $content = [regex]::Replace(
        $content,
        $pattern,
        [System.Text.RegularExpressions.MatchEvaluator]{
          param($match)
          return $match.Groups[1].Value + $link
        },
        1
      )

      [System.IO.File]::WriteAllText(
        $workshopPagePath,
        $content,
        (New-Object System.Text.UTF8Encoding($false))
      )

      Write-Host "Added Open live room button." -ForegroundColor Green
    }
    else {
      Write-Host "Could not insert the workshop button automatically. The live route is still installed." -ForegroundColor Yellow
    }
  }
}

Remove-Item -Recurse -Force (Join-Path $root ".next") -ErrorAction SilentlyContinue

$packageJson = Get-Content (Join-Path $root "package.json") -Raw | ConvertFrom-Json
$scripts = $packageJson.scripts

if ($null -ne $scripts -and $scripts.PSObject.Properties.Name -contains "typecheck") {
  Write-Host "Running typecheck..." -ForegroundColor Yellow
  npm.cmd run typecheck
}
elseif (Test-Path (Join-Path $root "tsconfig.json")) {
  Write-Host "Running TypeScript check..." -ForegroundColor Yellow
  npx.cmd tsc --noEmit
}

if ($LASTEXITCODE -ne 0) {
  Write-Host "TypeScript validation failed. Backup: $backup" -ForegroundColor Red
  exit 1
}

if ($null -ne $scripts -and $scripts.PSObject.Properties.Name -contains "build") {
  Write-Host "Running build..." -ForegroundColor Yellow
  npm.cmd run build

  if ($LASTEXITCODE -ne 0) {
    Write-Host "Build failed. Backup: $backup" -ForegroundColor Red
    exit 1
  }
}

Write-Host ""
Write-Host "REGISTERED LIVESTREAM MODULE INSTALLED" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Copy values from .env.livestream.example into .env.local"
Write-Host "2. Apply supabase\migrations\20260725_registered_livestream_system.sql"
Write-Host "3. Restart: npm.cmd run dev"
Write-Host "4. Open: http://localhost:3000/manager/livestreams"
